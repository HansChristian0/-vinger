#include "std_lib_facilities.h"
#include "animal.h"

int main() {
    //testAnimal();

    int n = 4;

    cout << ++n << n << n++ << n << endl;
    return 0;
}
