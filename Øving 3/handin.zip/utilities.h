#pragma once

int randomWithLimits(int a, int b);