#pragma once

void playMastermind();
int checkCharAndPosition(string løsning, string gjett);
int checkChar(string løsning, string gjett);
