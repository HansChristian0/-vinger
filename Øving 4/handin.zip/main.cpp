#include "std_lib_facilities.h"
#include "test.h"
#include "utilities.h"
#include "mastermind.h"
#include "masterVisual.h"

int main() {
    playMastermindVisual();
    return 0;
}