#pragma once

void fillInFibnumb(int* result, int length);
void printArray(int* arr, int length);
void createFib();